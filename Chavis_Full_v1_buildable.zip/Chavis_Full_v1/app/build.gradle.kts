plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.chavis.agent"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.chavis.agent"
        minSdk = 26
        targetSdk = 35
        versionCode = 100
        versionName = "1.0.0"
    }
}
