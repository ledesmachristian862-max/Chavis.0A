package com.chavis.agent

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ChavisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        scan(root)
    }

    private fun scan(node: AccessibilityNodeInfo) {
        val text = node.text?.toString()
        if (!text.isNullOrBlank()) {
            // Keep captured text local in this foundation.
            // Uploading it to an AI service must be explicitly authorized.
        }
        for (i in 0 until node.childCount) node.getChild(i)?.let(::scan)
    }

    override fun onInterrupt() {}
}
