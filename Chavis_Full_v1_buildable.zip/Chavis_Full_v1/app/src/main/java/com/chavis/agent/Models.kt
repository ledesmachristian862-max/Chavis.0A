package com.chavis.agent

enum class AgentMode { OFFLINE, ONLINE }

data class AgentResult(
    val text: String,
    val requiresApproval: Boolean = false
)

data class Slide(
    var title: String,
    var body: String
)

data class PresentationProject(
    var title: String,
    var slides: MutableList<Slide>
)
