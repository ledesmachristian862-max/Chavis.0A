package com.chavis.agent

import org.json.JSONArray
import org.json.JSONObject

object PresentationEngine {
    fun create(topic: String): PresentationProject {
        val t = topic.trim().ifEmpty { "Untitled Presentation" }
        return PresentationProject(
            t,
            mutableListOf(
                Slide(t, "Introduction and overview"),
                Slide("Key Concepts", "Definitions, important ideas, and background"),
                Slide("Examples", "Examples and practical applications"),
                Slide("Analysis", "Important observations and supporting points"),
                Slide("Summary", "Key points to remember"),
                Slide("Conclusion", "Final takeaway")
            )
        )
    }

    fun edit(project: PresentationProject, instruction: String): PresentationProject {
        val i = instruction.lowercase()
        if ("add" in i && "slide" in i)
            project.slides.add(Slide("New Slide", "Generated content"))
        if ("remove" in i && project.slides.isNotEmpty())
            project.slides.removeAt(project.slides.lastIndex)
        return project
    }

    fun toJson(project: PresentationProject): String {
        val o = JSONObject().put("title", project.title)
        val a = JSONArray()
        project.slides.forEach { a.put(JSONObject().put("title", it.title).put("body", it.body)) }
        o.put("slides", a)
        return o.toString()
    }
}
