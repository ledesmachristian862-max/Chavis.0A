package com.chavis.agent

class ToolRegistry {
    private val tools = mutableMapOf<String, (String) -> AgentResult>()

    fun register(name: String, handler: (String) -> AgentResult) {
        tools[name] = handler
    }

    fun run(name: String, input: String): AgentResult =
        tools[name]?.invoke(input) ?: AgentResult("Tool '$name' is not available.")
}
