package com.chavis.agent

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val agent = AgentEngine()
    private var project: PresentationProject? = null

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 45, 30, 25)
            setBackgroundColor(Color.rgb(12, 12, 18))
        }

        val title = TextView(this).apply {
            text = "CHAVIS"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "AI AGENT • FULL FOUNDATION v1.0"
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 5, 0, 15)
        }

        val mode = Spinner(this)
        mode.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Offline AI", "Online AI")
        )
        mode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                agent.mode = if (pos == 0) AgentMode.OFFLINE else AgentMode.ONLINE
            }
        }

        val command = EditText(this).apply {
            hint = "Command Chavis..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            minLines = 3
        }

        val output = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(0, 15, 0, 15)
        }

        val run = Button(this).apply {
            text = "RUN AGENT"
            setOnClickListener {
                val r = agent.run(command.text.toString())
                output.text = r.text
                if (r.requiresApproval) output.append("\n\nApproval required before device interaction.")
            }
        }

        val create = Button(this).apply {
            text = "BUILD PRESENTATION"
            setOnClickListener {
                project = PresentationEngine.create(command.text.toString())
                output.text = project!!.slides.mapIndexed { i, s ->
                    "${i + 1}. ${s.title}\n${s.body}"
                }.joinToString("\n\n")
            }
        }

        val edit = Button(this).apply {
            text = "EDIT PRESENTATION"
            setOnClickListener {
                val p = project
                if (p == null) {
                    output.text = "Create a presentation first."
                } else {
                    project = PresentationEngine.edit(p, command.text.toString())
                    output.text = project!!.slides.joinToString("\n\n") { "${it.title}\n${it.body}" }
                }
            }
        }

        val access = Button(this).apply {
            text = "ENABLE SCREEN / CONTROL"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        val messenger = Button(this).apply {
            text = "OPEN MESSENGER"
            setOnClickListener {
                val intent = packageManager.getLaunchIntentForPackage("com.facebook.orca")
                if (intent != null) startActivity(intent)
                else Toast.makeText(this, "Messenger is not installed.", Toast.LENGTH_SHORT).show()
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(mode)
        root.addView(command)
        root.addView(run)
        root.addView(create)
        root.addView(edit)
        root.addView(access)
        root.addView(messenger)
        root.addView(output)

        setContentView(root)
    }
}
