package com.chavis.agent

class AgentEngine {
    var mode = AgentMode.OFFLINE
    val tools = ToolRegistry()

    init {
        tools.register("presentation") {
            AgentResult("Presentation tool ready.")
        }
        tools.register("device") {
            AgentResult(
                "Device interaction requires explicit Android permission and user approval.",
                true
            )
        }
    }

    fun run(command: String): AgentResult {
        val c = command.trim()
        if (c.isEmpty()) return AgentResult("Enter a command.")

        val lower = c.lowercase()
        return when {
            lower.contains("presentation") ||
            lower.contains("powerpoint") ||
            lower.contains("slides") ->
                tools.run("presentation", c)
            lower.contains("screen") ||
            lower.contains("click") ||
            lower.contains("type") ||
            lower.contains("open") ->
                tools.run("device", c)
            else ->
                AgentResult(
                    "Chavis received: $c\nMode: ${mode.name.lowercase()}\nConnect an online provider or local model for general AI reasoning."
                )
        }
    }
}
