# Chavis Full v1

A foundation for an Android AI-agent assistant with:
- Online/offline agent abstraction
- User-authorized accessibility screen reading/control
- App launching
- Presentation project generation and editing
- Local project persistence
- Tool/skill registry
- Safety/approval gate for sensitive device actions

This package is source code, not a precompiled APK. Android Studio/Gradle is required to build the APK.

## Building the APK
**Option A – GitHub (no PC needed):** push this folder to a new GitHub repo, open the *Actions* tab, run *Build APK*, then download `Chavis-debug-apk` and unzip it to get `app-debug.apk`.

**Option B – Android Studio:** File > Open this folder, let Gradle sync, then Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.

The debug APK is auto-signed and can be installed directly (enable "Install unknown apps" for your file manager/browser).
